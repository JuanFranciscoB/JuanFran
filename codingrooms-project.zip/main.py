# 🚨 Don't change the code below 👇
print("Welcome to the Love Calculator!")
name1 = input("What is your name? \n")
name2 = input("What is their name? \n")
# 🚨 Don't change the code above 👆

#Write your code below this line 👇
true_score1 = 0
true_score2 = 0
love_score1 = 0
love_score2 = 0
lower_case_name1 = name1.lower()
lower_case_name2 = name2.lower()
t1 = lower_case_name1.count("t")
r1 = lower_case_name1.count("r")
u1 = lower_case_name1.count("u")
e1 = lower_case_name1.count("e")
l1 = lower_case_name1.count("l")
o1 = lower_case_name1.count("o")
v1 = lower_case_name1.count("v")
e1 = lower_case_name1.count("e")
t2 = lower_case_name2.count("t")
r2 = lower_case_name2.count("r")
u2 = lower_case_name2.count("u")
e2 = lower_case_name2.count("e")
l2 = lower_case_name2.count("l")
o2 = lower_case_name2.count("o")
v2 = lower_case_name2.count("v")
e2 = lower_case_name2.count("e")
print(f"""{name1}          {name2}
T {t1}                       T {t2} 
R {r1}                       R {r2} 
U {u1}                       U {u2}
E {e1}                       E {e2}
L {l1}                       L {l2}
O {o1}                       O {r2}
V {v1}                       V {v2}
E {e1}                       E {v2}""")

true_score1 = (t1 + r1 + u1 + e1)  
love_score1 = (l1 + o1 + v1 + e1)  
true_score2 = (t2 + r2 + u2 + e2) 
love_score2 = (l2 + o2 + v1 + e2)
total_true_score = true_score1 + true_score2
total_love_score = love_score1 + love_score2
total_score = str(total_true_score) + str(total_love_score)
total_score = int(total_score)
if total_score < 10 or total_score > 90:
    print(f"Your score is {total_score}, you go together like coke and mentos.")
elif total_score >= 40 and total_score <= 50:
    print(f"Your score is {total_score}, you are alright together.")
else:
    print(f"Your score is {total_score}.")

